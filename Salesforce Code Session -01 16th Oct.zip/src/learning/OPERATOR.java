package learning;

public class OPERATOR {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i;
		int j;
		i =0;
		j =0;
		
		
		System.out.println(i++);  //0 , first print then increment 
		System.out.println(++j);  // 1 ,first increment then print 
		
		System.out.println(i); //1
		System.out.println(j); //1
	}

}
