package learning;

public class grade {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		
		
		int hs,es,cs,ms;
		String name ="Raman sinha";
		
		hs=80;
		es =44;
		ms =77;
		cs =55;
		
		int total = hs+es+cs+ms;
		double avg = total /4;
		
		//print data on screen / console 
		System.out.println("total score is :"+total);
		System.out.println(avg);
		System.out.println("name is :"+name);
		
		//print grade
		if(avg>=80)
		{
			System.out.println("A");
		}
		else if(avg>=60)
		{
			System.out.println("B");
		}
		else if(avg>=40)
		{
			System.out.println("C");
		}
		else
		{
			System.out.println("D");
		}
				
	}

}
