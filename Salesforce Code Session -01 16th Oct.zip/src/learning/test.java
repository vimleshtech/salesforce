package learning;

public class test 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		int a =11;  //assign data 
		int b =4444; //assign data 
		
		
		int c = a+b;  //expression 
		
		System.out.println(c); //show output / print 
		

	       int rollnumber = 8595449; //
	       String name = "vikas barthwal";
	       int marks = 87;
	       int phone = 985467564; 
	       int number = 79;
	        number = number*number*number;
	        System.out.println(number);
	       
	    
	       
	       
		System.out.println(rollnumber);
		System.out.println(name);
		System.out.println(marks);
		System.out.println(phone);
		
		
	}

}