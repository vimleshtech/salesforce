package example;

import java.util.ArrayList;
import java.util.List;

public class startup {

	public static void main(String[] args) {

		/*
		product p =new product(1, "dove", 40);
		product p1 =new product(3, "lux", 30);
		
		p1.show();
		p.show();
		*/
		
		ArrayList<product> plist =new ArrayList<product>();
		
		plist.add(new product(1,"prod 1",40));
		plist.add(new product(2,"prod 2",400));
		plist.add(new product(3,"prod 3",340));
		plist.add(new product(4,"prod 4",410));
		
		
		for(int i=0; i<plist.size();i++)
		{
			System.out.print(plist.get(i).pid);
			System.out.print(plist.get(i).pname);
			System.out.println(plist.get(i).price);
			
		}
		
		

	}

}
