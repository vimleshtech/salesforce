package example;

public class product {

	public int pid;
	public String pname;
	public int price;

	//here id,name , p are parameter
	product(int id,String name, int p)  //constructor function 
	{
		pid = id;
		pname = name;
		price = p;
	}
	
	public void show()
	{
		double tax;
		tax = price*.05;
		
		System.out.println(pid);
		System.out.println(pname);
		System.out.println(price);
		System.out.println(tax);
		
	}

}
